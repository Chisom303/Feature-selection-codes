# Noise-robust multi-objective feature selection with leakage testing for IoMT intrusion detection

Code and run-level results for the manuscript "Noise-Robust Multi-Objective Feature Selection with Leakage
Testing for Intrusion Detection in Internet of Medical Things Networks".

## Data
The raw data are not redistributed. Download the CICIoMT2024 dataset from the Canadian Institute for
Cybersecurity (https://www.unb.ca/cic/datasets/iomt-dataset-2024.html), folder `WiFi_and_MQTT/attacks/csv`,
and place these files next to the notebooks:

- `Train/`: ARP_Spoofing, Benign, MQTT-DDoS-Connect_Flood, MQTT-Malformed_Data, Recon-Port_Scan,
  Recon-VulScan, TCP_IP-DDoS-SYN1 to 4 and TCP_IP-DoS-SYN1 to 4 (`*_train.pcap.csv`)
- `Test/`: the same eight classes (`*_test.pcap.csv`)

## Notebooks (run in this order)
| Notebook | Purpose | Output |
|---|---|---|
| `0_Setup_Environment.ipynb` | Creates the `iomt` Python environment and Jupyter kernel | kernel "Python (iomt)" |
| `1_Data_Cleaning.ipynb` | Label coding and cleaning rules C1 to C10 (train and test kept separate) | `cleaned_data/` |
| `3_Revised_Experiments.ipynb` | Main experiment: 10 runs, 7 feature configurations, statistics | `results_revised/` |
| `4_Supplementary_Analyses.ipynb` | Reproducibility check, extra baselines, other perturbations, decision tree, full test set, threshold, stability (Nogueira), TOST, effect sizes, sensitivity, hypervolume, IAT tests | `results_supplementary/` |

Notebook 1 should report 1,713,169 training and 375,743 test records. Notebook 3 takes several hours and
saves a checkpoint after every run. Notebook 4 reads `results_revised/checkpoint.pkl` and re-trains the saved
subsets; it should report `proposed_subset_reproduced_runs 10` and differences of 0.0.

To reproduce Notebook 4 without re-running Notebook 3, copy `results/results_revised/checkpoint.pkl` from
this repository to `results_revised/checkpoint.pkl`.

## Included results
- `results/cleaning/`: cleaning log and class counts (Tables 2 and 3)
- `results/results_revised/`: main experiment results and checkpoint (Tables 5 to 7, 13)
- `results/results_supplementary/`: supplementary results (Tables 8 to 12, 14, 15)

## Environment
Jupyter notebooks in an Anaconda environment. Package requirements are in `requirements.txt`.
Main experiment: Intel Core i5-6300U laptop. Supplementary analysis: Intel Core i7-8650U laptop.

## Licence and citation
[Add a licence, for example MIT, and the article citation once published.]
